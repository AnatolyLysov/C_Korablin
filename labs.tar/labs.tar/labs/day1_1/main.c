#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char *argv[]) {
	unsigned long int n1;
	long n2=7;
	
	double a,b=7,c=2;
	a=b/c;
	
	unsigned char k1=45;	//
	long long k2=17LL;	
	double k3=.4;
	float k4=4.1L;

	printf("Text!\n");
	printf("%d  %lld %s",k3,12345678913LL,"C++");
	
	return 0;
}


