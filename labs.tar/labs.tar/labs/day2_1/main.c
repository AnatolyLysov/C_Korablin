#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	
	//float			f=1.0f;			scanf("%f",&f);		printf("%f\n",f);
	
	//fflush(stdin);
	//unsigned char   c='!';			scanf("%c",&c);		printf("%c\n",c);
	long long 		l=2LL;			printf("%lld\n",l);
	
	short h=3,n=4,m=5;	
	
	scanf("h=%hi,n=%hi %hi",&h,&n,&m);
	printf("%i %i %i\n",h,n,m);
	printf("%s\n","hello ������");
	
	return 0; 
}




