#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	int i=1,n=3;
	
	for(i=1; i<=n; printf("Help "), i++) ;

//	while(n>=1) {
//		printf("Help ");
//		n--;
//	}
//	do {
//		printf("Help ");
//		n--;
//	}while(n>=1);

	return 0;
}
